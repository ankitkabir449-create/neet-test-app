# NEET Multi-language Offline Test App (Scaffold)
This is a minimal ready-to-run scaffold for a NEET test app with:
- Multi-language support (hi, en, bn, ta, te)
- Offline-enabled (prebundled sample data)
- Previous year papers (2017-2024 dummy data)
- Ad-free configuration

## What's inside
- `frontend/` : React Native scaffold (simple screens)
- `backend/`  : Node.js + Express scaffold with sample models and a loader
- `sampleData/` : JSON files for 2017-2024 dummy papers
- `README.md` : This file

## Quick start (local)
1. Install Node.js (v14+) and npm.
2. Start MongoDB locally (or change `MONGO_URI` in backend/.env).
3. Backend:
   ```
   cd backend
   npm install
   node loadSampleData.js
   node server.js
   ```
4. Frontend (React Native):
   ```
   cd frontend
   npm install
   npm start
   ```
5. Zip already prepared as `neet-app-final.zip` in package root.

This scaffold is a starting point. Replace sample PDFs/questions with real data and extend features as needed.
