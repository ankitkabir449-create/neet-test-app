const mongoose = require('mongoose');

const PaperSchema = new mongoose.Schema({
  title: String,
  year: Number,
  fileUrl: String,
  language: { type: String, default: 'hi' },
  parsed: { type: Boolean, default: false },
  uploadedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Paper', PaperSchema);
