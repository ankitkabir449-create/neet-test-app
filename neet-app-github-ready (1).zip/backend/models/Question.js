const mongoose = require('mongoose');

const QuestionSchema = new mongoose.Schema({
  year: Number,
  text: { type: Object, default: {} },   // {hi: '', en: '', ...}
  options: { type: Object, default: {} },// {hi: [], en: [], ...}
  correctAnswer: Number,
  language: { type: String, default: 'hi' },
  sourcePaper: { type: mongoose.Schema.Types.ObjectId, ref: 'Paper' }
});

module.exports = mongoose.model('Question', QuestionSchema);
