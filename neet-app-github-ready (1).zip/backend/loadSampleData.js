// Load sample papers and questions into MongoDB
const mongoose = require('mongoose');
const fs = require('fs');
const Question = require('./models/Question');
const Paper = require('./models/Paper');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/neetapp';

async function main(){
  await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
  console.log('Connected to MongoDB');

  // Clear existing sample data (non-destructive if you have real data)
  // await Question.deleteMany({});
  // await Paper.deleteMany({});

  const sampleDir = __dirname + '/..' + '/sampleData';
  const files = fs.readdirSync(sampleDir).filter(f => f.endsWith('.json'));
  for(const f of files){
    const data = JSON.parse(fs.readFileSync(sampleDir + '/' + f, 'utf-8'));
    const paper = await Paper.create({ title: data.title, year: data.year, language: data.language || 'hi', parsed: true });
    for(const q of data.questions){
      await Question.create({
        year: data.year,
        text: q.text,
        options: q.options,
        correctAnswer: q.correctAnswer,
        language: 'hi',
        sourcePaper: paper._id
      });
    }
    console.log('Loaded', data.title);
  }
  console.log('Done loading sample data');
  process.exit(0);
}

main().catch(err => { console.error(err); process.exit(1); });
