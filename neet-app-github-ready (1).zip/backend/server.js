const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');

const Question = require('./models/Question');
const Paper = require('./models/Paper');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/neetapp';

mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
.then(() => console.log('✅ MongoDB connected'))
.catch(err => console.error('Mongo error', err));

// Basic routes
app.get('/', (req, res) => {
  res.send('NEET Backend Running');
});

// Get papers
app.get('/papers', async (req, res) => {
  const papers = await Paper.find().sort({year:-1});
  res.json(papers);
});

// Get questions for a paper (language-aware)
app.get('/papers/:id/questions', async (req, res) => {
  const lang = req.query.lang || 'hi';
  const paperId = req.params.id;
  const qs = await Question.find({ sourcePaper: paperId });
  // map questions to language fallback
  const mapped = qs.map(q => {
    const text = (q.text && q.text[lang]) || (q.text && q.text.hi) || q.text.en || '';
    const options = (q.options && q.options[lang]) || (q.options && q.options.hi) || q.options.en || [];
    return {
      _id: q._id,
      year: q.year,
      text,
      options,
      correctAnswer: q.correctAnswer
    };
  });
  res.json(mapped);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log('🚀 Backend listening on', PORT));
